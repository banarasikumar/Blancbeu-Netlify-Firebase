# HAPPY DIWALI

A Pen created on CodePen.

Original URL: [https://codepen.io/Rohitth/pen/BGoxVp](https://codepen.io/Rohitth/pen/BGoxVp).

